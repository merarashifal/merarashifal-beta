<div class="hl-main-wraper">
   <div class="container-fluid">
        <div class="hl-card-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="hl-hotal-tabs">
                        <ul>  
                            <li>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=appointment_schedule')); ?>" class="Astro_active" ><img src="<?php echo esc_url(plugins_url(). '/astro-appointment/admin/images/bed.png'); ?>" alt="<?php esc_attr_e('Schedule Icon ','astro'); ?>"><?php echo esc_html__('Schedule','astro'); ?></a> 
                            </li> 
                            <li> 
                             <a href="<?php echo esc_url(admin_url('admin.php?page=appointment_booking')); ?>"><img src="<?php echo esc_url(plugins_url(). '/astro-appointment/admin/images/calendar.png'); ?>" alt="<?php esc_attr_e('Bookings icon','astro'); ?>"><?php echo esc_html__('Bookings','astro'); ?></a>
                            </li>
                            <li>
                             <a href="<?php echo esc_url(admin_url('admin.php?page=appointment_paymentsetting')); ?>"><img src="<?php echo esc_url(plugins_url(). '/astro-appointment/admin/images/credit-card.png'); ?>" alt="<?php esc_attr_e('Payment icon','astro'); ?>"><?php echo esc_html__('Payment Settings','astro'); ?></a>
                            </li>
                            <li>
                             <a href="<?php echo esc_url(admin_url('admin.php?page=appointment_formsetting')); ?>"><img src="<?php echo esc_url(plugins_url(). '/astro-appointment/admin/images/form.png'); ?>" alt="<?php esc_attr_e('Form icon','astro'); ?>"><?php echo esc_html__('Form Settings','astro'); ?></a> 
                            </li> 
                        </ul>
                    </div>
                </div>
            </div> 
            <div class="hl-table-header table-controls">
             <?php echo "<h1 class='hl-heading-title'>".esc_html__('Schedule List','astro')."</h1>";?>
             <div class="room-list-header">
                 <a href="<?php echo esc_url(admin_url('post-new.php?post_type=schedule')); ?>" class="hl-btn"><?php echo esc_html__('Create Schedule ','astro'); ?></a>
			    <a href="javascript:void(0);" class="hl-btn" id="xlsexport"><?php echo esc_html__('Xls Export','astro'); ?></a>
				<a href="javascript:void(0);" class="hl-btn" id="csvexport"><?php echo esc_html__('CSV Export','astro'); ?></a>
             </div>
            </div>  
            <form method="get" class="user-form-listing">
	            <input type="hidden" name="post_type" value="schedule" />
                <input type="hidden" name="page" value="<?php echo wp_kses($_REQUEST['page'],true); ?>" />
                <?php   
                require dirname( __FILE__ ) . '/astro-appointment-data-list.php';
                $list_table = new Astro_appointment_schedule_list();
                $list_table->prepare_items();
                $list_table->search_box('Search', 'search');
                ?>
                <div class="hl-table-wrapper">
                <?php
                 $list_table->display();
                ?>  
                </div>  
            </form>
          </div>
    </div>
</div>