<div class="hl-main-wraper">
 <div class="container-fluid">
    <div class="hl-card-body">
        <div class="row">
            <div class="col-lg-12">
                <div class="hl-hotal-tabs">
                    <ul>
                       <li>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=event-options')); ?>"><img src="<?php echo esc_url(plugins_url(). '/astro-appointment/admin/images/bed.png'); ?>" class="Astro_active" alt="<?php esc_attr_e('Event icon ','astro'); ?>"><?php echo esc_html__('Event','astro'); ?></a> 
                        </li>
                        <li>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=cafe_booking')); ?>" class="Astro_active"><img src="<?php echo esc_url(plugins_url(). '/astro-appointment/admin/images/calendar.png'); ?>" alt="<?php esc_attr_e('Bookings icon','astro'); ?>"><?php echo esc_html__('Bookings','astro'); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=cafe_payment')); ?>"><img src="<?php echo esc_url(plugins_url(). '/astro-appointment/admin/images/credit-card.png'); ?>" alt="<?php esc_attr_e('Payment icon','astro'); ?>"><?php echo esc_html__('Payment Settings','astro'); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=cafe_form')); ?>"><img src="<?php echo esc_url(plugins_url(). '/astro-appointment/admin/images/form.png'); ?>" alt="<?php esc_attr_e('Form icon','astro'); ?>"><?php echo esc_html__('Form Settings','astro'); ?></a> 
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <form method="get" class="user-form-listing">
            <input type="hidden" name="post_type" value="<?php echo esc_attr__('event','astro'); ?>" /> 
            <input type="hidden" name="page" value="<?php echo wp_kses($_REQUEST['page'],true); ?>" />
			<a href="javascript:void(0);" class="hl-btn" id="xlsexport"><?php echo esc_html__('Xls Export','astro'); ?></a>
				<a href="javascript:void(0);" class="hl-btn" id="csvexport"><?php echo esc_html__('CSV Export','astro'); ?></a>
            <?php 
            echo "<h1 class='hl-heading-title'>".esc_html__('Booking List','astro')."</h1>";
            require dirname( __FILE__ ) . '/astro-event-data-list.php';
            $list_table = new Astro_cafe_booking_Table(); 
            $list_table->prepare_items();
            $list_table->search_box('Search', 'search');
            ?>
            <div class="hl-table-wrapper">
            <?php $list_table->display(); ?>
            </div>
        </form> 
    </div>
</div>