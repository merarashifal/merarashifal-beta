<div class="hl-main-wraper">
   <div class="container-fluid">
        <div class="hl-card-body">
        <h1 class="hl-heading-title"><?php echo esc_html__('Social Share','astro'); ?></h1>
        <div class="row">
            <div class="col-lg-12">
              <div class="hl-social-network-list">
                <ul>
                       <li>
                        <a href="<?php echo esc_url('https://www.facebook.com/sharer/sharer.php?u='.home_url()); ?>" id="facebook" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/facebook_img.png'); ?>" alt="<?php echo esc_attr__('Facebook','astro'); ?>">
                            <span><?php echo esc_html__('Facebook','astro'); ?></span>
                        </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.facebook.com/dialog/send?app_id=329829260786620&amp;link='.home_url()); ?>" id="facebook_messenger" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/facebook_messengerimg.png'); ?>" alt="<?php echo esc_attr__('Facebofacebook messengerimg','astro'); ?>">
                                <span><?php echo esc_html__('Facebook Messenger','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://twitter.com/share?url='.home_url()); ?>" id="twitter" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/twitter-img.png'); ?>" alt="<?php echo esc_attr__('twitter','astro'); ?>">
                                <span><?php echo esc_html__('Twitter','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://pinterest.com/pin/create/bookmarklet/?&amp;url='.home_url()); ?>" id="pinterest" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/pinterest-pinimg.png'); ?>" alt="<?php echo esc_attr__('pinterest','astro'); ?>">
                                <span><?php echo esc_html__('Pinterest','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://wa.me/?text='.home_url()); ?>" id="whatsapp" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/whatsapp-img.png'); ?>" alt="<?php echo esc_attr__('Whatsapp','astro'); ?>">
                                <span><?php echo esc_html__('Whatsapp','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.viber.com/en/download/?text='.home_url()); ?>" id="viber" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/Viber.png'); ?>" alt="<?php echo esc_attr__('Viber','astro'); ?>">
                                <span><?php echo esc_html__('Viber','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://accounts.snapchat.com/accounts/login?client_id=geo'); ?>" id="snapchat" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/social-snapchat.png'); ?>" alt="<?php echo esc_attr__('social-snapchat','astro'); ?>">
                                <span><?php echo esc_html__('Snapchat','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.linkedin.com/shareArticle?mini=true&amp;url='.home_url()); ?>" id="linkedin" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/linkedin-img.png'); ?>" alt="<?php echo esc_attr__('linkedin','astro'); ?>">
                                <span><?php echo esc_html__('Linkedin','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://reddit.com/submit?url='.home_url()); ?>" id="reddit" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/reddit-img.png'); ?>" alt="<?php echo esc_attr__('reddit','astro'); ?>">
                                <span><?php echo esc_html__('Reddit','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.tumblr.com/widgets/share/tool?canonicalUrl='.home_url()); ?>" id="tumblr" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/tumblr-img.png'); ?>" alt="<?php echo esc_attr__('tumblr','astro'); ?>">
                                <span><?php echo esc_html__('Tumblr','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.quora.com/'); ?>" id="quora" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/Quora-256.png'); ?>" alt="<?php echo esc_attr__('Quora','astro'); ?>">
                                <span><?php echo esc_html__('Quora','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://nextdoor.com/'); ?>" id="nextdoor" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/nextdoor.png'); ?>" alt="<?php echo esc_attr__('nextdoor','astro'); ?>">
                                <span><?php echo esc_html__('Nextdoor','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://foursquare.com/login'); ?>" id="foursquare" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/Foursquare-256.png'); ?>" alt="<?php echo esc_attr__('Foursquare','astro'); ?>">
                                <span><?php echo esc_html__('Foursquare','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://secure.meetup.com/login/'); ?>" id="meetup" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/MeetUp.png'); ?>" alt="<?php echo esc_attr__('MeetUp','astro'); ?>">
                                <span><?php echo esc_html__('Meetup','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://deliciouskebabst5.com/'); ?>" id="delicious" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/delicious-img.png'); ?>" alt="<?php echo esc_attr__('delicious','astro'); ?>">
                                <span><?php echo esc_html__('Delicious','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('http://digg.com/submit?phase=2&amp;url='); ?>" id="digg" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/digg-img.png'); ?>" alt="<?php echo esc_attr__('digg','astro'); ?>">
                                <span><?php echo esc_html__('Digg','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.evernote.com/clip.action?url='.home_url()); ?>" id="evernote" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/Evernote.png'); ?>" alt="<?php echo esc_attr__('Evernote','astro'); ?>">
                                <span><?php echo esc_html__('Evernote','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://share.flipboard.com/bookmarklet/popout?url='.home_url()); ?>" id="flipboard" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/flipboard-img.png'); ?>" alt="<?php echo esc_attr__('flipboard','astro'); ?>">
                                <span><?php echo esc_html__('Flipboard','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://impif.com/sharer?url='.home_url()); ?>" id="impif" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/impif.png'); ?>" alt="<?php echo esc_attr__('impif','astro'); ?>">
                                <span><?php echo esc_html__('Impif','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://meneame.net/login?return=/submit?url='.home_url()); ?>" id="meneame" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/meneame-img.png'); ?>" alt="<?php echo esc_attr__('meneame','astro'); ?>">
                                <span><?php echo esc_html__('Meneame','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://vk.com/share.php?url='.home_url()); ?>" id="vvontakte" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/vk-img.png'); ?>" alt="<?php echo esc_attr__('vk','astro'); ?>">
                                <span><?php echo esc_html__('Vkontakte','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.blogger.com/blog_this.pyra?t&amp;u='.home_url()); ?>" id="blogger" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/blogger_img.png'); ?>" alt="<?php echo esc_attr__('blogger_img','astro'); ?>">
                                <span><?php echo esc_html__('Blogger','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('mailto:?body='.home_url()); ?>" id="email" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/email-img.png'); ?>" alt="<?php echo esc_attr__('email','astro'); ?>">
                                <span><?php echo esc_html__('Email','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.xing.com/app/user?op=share&amp;url='.home_url()); ?>" id="xing" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/xing-img.png'); ?>" alt="<?php echo esc_attr__('xing-img','astro'); ?>">
                                <span><?php echo esc_html__('Xing','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://connect.mail.ru/share?share_url='.home_url()); ?>" id="mailru" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/mail-ruimg.png'); ?>" alt="<?php echo esc_attr__('mail-ruimg','astro'); ?>">
                                <span><?php echo esc_html__('Mail Ru','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('http://www.livejournal.com/update.bml?event='.home_url()); ?>" id="livejournal" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/livejournal-img.png'); ?>" alt="<?php echo esc_attr__('livejournal','astro'); ?>">
                                <span><?php echo esc_html__('Livejournal','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://myspace.com/post?l=3&amp;u='.home_url()); ?>" id="myspace" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/myspace.png'); ?>" alt="<?php echo esc_attr__('myspace','astro'); ?>">
                                <span><?php echo esc_html__('MySpace','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://buffer.com/add?url='.home_url()); ?>" id="buffer" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/buffer_img.png'); ?>" alt="<?php echo esc_attr__('buffer','astro'); ?>">
                                <span><?php echo esc_html__('Buffer','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('http://www.douban.com/share/service?url='.home_url()); ?>" id="douban" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/douban-img.png'); ?>" alt="<?php echo esc_attr__('douban','astro'); ?>">
                                <span><?php echo esc_html__('Douban','astro'); ?></span>
                            </a>
                        </li>
                        
                        <li>
                            <a href="<?php echo esc_url('http://b.hatena.ne.jp/bookmarklet?url='.home_url()); ?>" id="hatena" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/hatena.png'); ?>" alt="<?php echo esc_attr__('hatena','astro'); ?>">
                                <span><?php echo esc_html__('Hatena','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.google.com/bookmarks/mark?op=edit&amp;bkmk='.home_url()); ?>" id="googlebookmarks" target="_blank"> 
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/bookmarks_img.png'); ?>" alt="<?php echo esc_attr__('bookmarks_img','astro'); ?>">
                                <span><?php echo esc_html__('Google Bookmarks','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://mail.google.com/mail/?view=cm&fs=1&tf=1&to=&su=Your+Subject+here&body='.home_url()); ?>" id="gmail" target="_blank"> 
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/gmail-img.png'); ?>" alt="<?php echo esc_attr__('gmail','astro'); ?>">
                                <span><?php echo esc_html__('Gmail','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://news.ycombinator.com/submitlink?u='.home_url()); ?>" id="hackernews" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/hackernews-img.png'); ?>" alt="<?php echo esc_attr__('hackernews','astro'); ?>">
                                <span><?php echo esc_html__('HackerNews','astro'); ?></span>
                            </a> 
                        </li>
                        <li>
                            <a href="<?php echo esc_url('http://www.instapaper.com/edit?url='.home_url()); ?>" id="instapaper" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/instapaper-img.png'); ?>" alt="<?php echo esc_attr__('instapaper','astro'); ?>">
                                <span><?php echo esc_html__('Instapaper','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://lineit.line.me/share/ui?url='.home_url()); ?>" id="line" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/line-img.png'); ?>" alt="<?php echo esc_attr__('line','astro'); ?>">
                                <span><?php echo esc_html__('Line','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://getpocket.com/edit?url='.home_url()); ?>" id="pocket" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/pocketimg.png'); ?>" alt="<?php echo esc_attr__('pocketimg','astro'); ?>">
                                <span><?php echo esc_html__('Pocket','astro'); ?></span>
                            </a>
                        </li>
                    
                        <li>
                            <a href="<?php echo esc_url('https://share.diasporafoundation.org/?title=Onboarding%20CMP%20-%20ShareThis&amp;url='.home_url()); ?>" id="diaspora" target="_blank"> 
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/diaspora-img.png'); ?>" alt="<?php echo esc_attr__('diaspora','astro'); ?>">
                                <span><?php echo esc_html__('Diaspora','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('http://surfingbird.ru/share?url='.home_url()); ?>" id="surfingbird" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/surfingbird-img.png'); ?>" alt="<?php echo esc_attr__('surfingbird','astro'); ?>">
                                <span><?php echo esc_html__('Surfingbird','astro'); ?></span>
                            </a> 
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://refind.com/?url='.home_url()); ?>" id="refind" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/refind-img.png'); ?>" alt="<?php echo esc_attr__('refind','astro'); ?>">
                                <span><?php echo esc_html__('Refind','astro'); ?></span>
                            </a> 
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://web.skype.com/share?url='.home_url()); ?>" id="skype" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/skype-img.png'); ?>" alt="<?php echo esc_attr__('skype','astro'); ?>">
                                <span><?php echo esc_html__('Skype','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://telegram.me/share/url?url='.home_url()); ?>" id="telegram" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/telegram-img.png'); ?>" alt="<?php echo esc_attr__('telegram','astro'); ?>">
                                <span><?php echo esc_html__('Telegram','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://wordpress.com/log-in?redirect_to='.home_url()); ?>" id="wordpress" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/wordpress-img.png'); ?>" alt="<?php echo esc_attr__('wordpress','astro'); ?>">
                                <span><?php echo esc_html__('WordPress','astro'); ?></span>
                            </a>
                        </li>
                        
                        <li>
                            <a href="<?php echo esc_url('http://compose.mail.yahoo.com/?body='.home_url()); ?>" id="yahoomail" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/yahoomail-img.png'); ?>" alt="<?php echo esc_attr__('yahoomail','astro'); ?>">
                                <span><?php echo esc_html__('Yahoo Mail','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://mixi.jp/?url='.home_url()); ?>" id="mixi" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/mixi.png'); ?>" alt="<?php echo esc_attr__('mixi','astro'); ?>">
                                <span><?php echo esc_html__('Mixi','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.amazon.com/gp/wishlist/static-add?u='.home_url()); ?>" id="amazon" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/Amazon-512.png'); ?>" alt="<?php echo esc_attr__('Amazon','astro'); ?>">
                                <span><?php echo esc_html__('Amazon','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('http://www.newsvine.com/_tools/seed&amp;save?u='.home_url()); ?>" id="newsvine" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/Newsvine.png'); ?>" alt="<?php echo esc_attr__('Newsvine','astro'); ?>">
                                <span><?php echo esc_html__('Newsvine','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://app.clubhouse.io/login?url='.home_url()); ?>" id="clubhouse" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/clubhouse.png'); ?>" alt="<?php echo esc_attr__('clubhouse','astro'); ?>">
                                <span><?php echo esc_html__('Clubhouse','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.viadeo.com/shareit/share/?url='.home_url()); ?>" id="viadeo" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/viadeo-512.png'); ?>" alt="<?php echo esc_attr__('Facebook','astro'); ?>">
                                <span><?php echo esc_html__('Viadeo','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://story.kakao.com/share?url='.home_url()); ?>" id="kakao" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/kakao.png'); ?>" alt="<?php echo esc_attr__('kakao','astro'); ?>">
                                <span><?php echo esc_html__('Kakao','astro'); ?></span>
                            </a>
                        </li>
                    
                        <li>
                            <a href="<?php echo esc_url('https://www.wykop.pl/remotelink/?url='.home_url()); ?>" id="wykop" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/logo-wykop-vector.png'); ?>" alt="<?php echo esc_attr__('logo-wykop-vector','astro'); ?>">
                                <span><?php echo esc_html__('Wykop','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://secure.tagged.com/?url='.home_url()); ?>" id="tagged" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/Tagged-512.png'); ?>" alt="<?php echo esc_attr__('Tagged','astro'); ?>">
                                <span><?php echo esc_html__('Tagged','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://badoo.com/?url='.home_url()); ?>" id="badoo" target="_blank">
                            <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/Badoo-512.png'); ?>" alt="<?php echo esc_attr__('Badoo','astro'); ?>">
                            <span><?php echo esc_html__('Badoo','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.skyrock.com/?url='.home_url()); ?>" id="skyrock" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/Skyrock.png'); ?>" alt="<?php echo esc_attr__('Skyrock','astro'); ?>">
                                <span><?php echo esc_html__('Skyrock','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('http://www.yummly.com/urb/verify?url='.home_url()); ?>" id="yummly" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/Yummly.png'); ?>" alt="<?php echo esc_attr__('Yummly','astro'); ?>">
                                <span><?php echo esc_html__('Yummly','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.cellufun.com/games.asp?url='.home_url()); ?>" id="cellufun" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/cellufun.png'); ?>" alt="<?php echo esc_attr__('cellufun','astro'); ?>">
                                <span><?php echo esc_html__('Cellufun','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.wattpad.com/?url='.home_url()); ?>" id="wattpad" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/wattpad.png'); ?>" alt="<?php echo esc_attr__('wattpad','astro'); ?>">
                                <span><?php echo esc_html__('Wattpad','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.crunchyroll.com/?url='.home_url()); ?>" id="crunchyroll" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/crunchyroll.png'); ?>" alt="<?php echo esc_attr__('crunchyroll','astro'); ?>">
                                <span><?php echo esc_html__('Crunchyroll','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.caringbridge.org/?url='.home_url()); ?>" id="caringBridge" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/caring-bridge.png'); ?>" alt="<?php echo esc_attr__('caring-bridge','astro'); ?>">
                                <span><?php echo esc_html__('CaringBridge','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://steemit.com/?url='.home_url()); ?>" id="steemit" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/steemit.png'); ?>" alt="<?php echo esc_attr__('steemit','astro'); ?>">
                                <span><?php echo esc_html__('Steemit','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.caffeine.tv/?url='.home_url()); ?>" id="caffeine" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/caffeine.png'); ?>" alt="<?php echo esc_attr__('caffeine','astro'); ?>">
                                <span><?php echo esc_html__('Caffeine','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://houseparty.com/?url='.home_url()); ?>" id="houseParty" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/houseparty.png'); ?>" alt="<?php echo esc_attr__('houseparty','astro'); ?>">
                                <span><?php echo esc_html__('HouseParty','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://valence.community/?url='.home_url()); ?>" id="valence" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/valence.png'); ?>" alt="<?php echo esc_attr__('valence','astro'); ?>">
                                <span><?php echo esc_html__('Valence','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.pop-base.com/?url='.home_url()); ?>" id="popbase" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/pop_base.png'); ?>" alt="<?php echo esc_attr__('pop_base','astro'); ?>">
                                <span><?php echo esc_html__('PopBase','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://yubo.live/en?url='.home_url()); ?>" id="yubo" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/yubo.png'); ?>" alt="<?php echo esc_attr__('yubo','astro'); ?>">
                                <span><?php echo esc_html__('Yubo','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://elpha.com/?url='.home_url()); ?>" id="elpha" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/elpha.png'); ?>" alt="<?php echo esc_attr__('elpha','astro'); ?>">
                                <span><?php echo esc_html__('Elpha','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.triller.co/?url='.home_url()); ?>" id="triller" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/triller.png'); ?>" alt="<?php echo esc_attr__('triller','astro'); ?>">
                                <span><?php echo esc_html__('Triller','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://cafemom.com/'); ?>" id="cafeMom" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/cafemom.png'); ?>" alt="<?php echo esc_attr__('cafemom','astro'); ?>">
                                <span><?php echo esc_html__('CafeMom','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://discord.com/?url='.home_url()); ?>" id="discord" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/discord.png'); ?>" alt="<?php echo esc_attr__('discord','astro'); ?>">
                                <span><?php echo esc_html__('Discord','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://medium.com/'); ?>" id="medium" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/Medium.png'); ?>" alt="<?php echo esc_attr__('Medium','astro'); ?>">
                                <span><?php echo esc_html__('Medium','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.twitch.tv/?url='.home_url()); ?>" id="twitch" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/twitch_PNG28.png'); ?>" alt="<?php echo esc_attr__('twitch','astro'); ?>">
                                <span><?php echo esc_html__('Twitch','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.goodreads.com/?url='.home_url()); ?>" id="goodreads" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/goodreads-round-light-1-512.png'); ?>" alt="<?php echo esc_attr__('goodreads-round-light','astro'); ?>">
                                <span><?php echo esc_html__('Goodreads','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.peanut-app.io/?url='.home_url()); ?>" id="peanut" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/Peanut.png'); ?>" alt="<?php echo esc_attr__('Peanut','astro'); ?>">
                                <span><?php echo esc_html__('Peanut','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.meetme.com/?url='.home_url()); ?>" id="meetme" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/meetme.png'); ?>" alt="<?php echo esc_attr__('meetme','astro'); ?>">
                                <span><?php echo esc_html__('MeetMe','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.buzznet.com/?url='.home_url()); ?>" id="buzznet" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/Buzznet.png'); ?>" alt="<?php echo esc_attr__('Buzznet','astro'); ?>">
                                <span><?php echo esc_html__('Buzznet','astro'); ?></span>
                            </a>
                        </li>
                        
                        <li>
                            <a href="<?php echo esc_url('https://www.funnyordie.com/?url='.home_url()); ?>" id="funnyordie" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/funnyordie.png'); ?>" alt="<?php echo esc_attr__('funnyordie','astro'); ?>">
                                <span><?php echo esc_html__('Funny or Die','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.myheritage.com/?url='.home_url()); ?>" id="myheritage" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/MyHeritage.png'); ?>" alt="<?php echo esc_attr__('MyHeritage','astro'); ?>">
                                <span><?php echo esc_html__('MyHeritage','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.classmates.com/?url='.home_url()); ?>" id="classmates" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/Classmates.png'); ?>" alt="<?php echo esc_attr__('Classmates','astro'); ?>">
                                <span><?php echo esc_html__('Classmates','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://weheartit.com/?url='.home_url()); ?>" id="weheartit" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/weloveit.png'); ?>" alt="<?php echo esc_attr__('weloveit','astro'); ?>">
                                <span><?php echo esc_html__('We Heart It','astro'); ?></span>
                            </a>
                        </li>
                    
                        <li>
                            <a href="<?php echo esc_url('https://www.care2.com/?url='.home_url()); ?>" id="care2" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/care2.png'); ?>" alt="<?php echo esc_attr__('care2','astro'); ?>">
                                <span><?php echo esc_html__('Care2','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.wayn.com/?url='.home_url()); ?>" id="wayn" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/wayn.png'); ?>" alt="<?php echo esc_attr__('wayn','astro'); ?>">
                                <span><?php echo esc_html__('Wayn','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.flixster.com/?url='.home_url()); ?>" id="flixster" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/Flixster.png'); ?>" alt="<?php echo esc_attr__('Flixster','astro'); ?>">
                                <span><?php echo esc_html__('Flixster','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.reverbnation.com/?url='.home_url()); ?>" id="reverbnation" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/ReverbNation.png'); ?>" alt="<?php echo esc_attr__('ReverbNation','astro'); ?>">
                                <span><?php echo esc_html__('ReverbNation','astro'); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo esc_url('https://www.snapfish.com/home?url='.home_url()); ?>" id="snapfish" target="_blank">
                                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/assets/images/social/snapfish.png'); ?>" alt="<?php echo esc_attr__('snapfish','astro'); ?>">
                                <span><?php echo esc_html__('Snapfish','astro'); ?></span>
                            </a>
                        </li>
                        </ul>
                    </div>
                </div>
            </div>
         </div>
    </div>
</div>