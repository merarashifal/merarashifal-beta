<?php 
// astro event management