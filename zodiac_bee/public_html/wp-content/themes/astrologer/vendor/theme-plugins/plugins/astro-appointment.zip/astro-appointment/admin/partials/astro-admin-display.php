<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://codecanyon.net/user/kamleshyadav
 * @since      1.0.0
 *
 * @package    Astro
 * @subpackage Astro/admin/partials
 */
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="hl-main-wraper">
    <div class="container">
      <div class="row">
         <div class="col-md-12">
              <div class="hl-welcome-wrap">
                <h1><?php echo esc_html__('Welcome To','astro'); ?><span><?php echo esc_html__(' Astro','astro'); ?></span></h1>
                </div> 
           </div>
       </div>
      
     <div class="hl-card-body">
       <div class="row">
        <?php 
        $Astro_startbooking = get_option('Astro_connection_details');
        if(!empty($Astro_startbooking)):
        ?> 
        <div class="col-lg-4 offset-lg-4">
            <?php 
            switch ($Astro_startbooking):
              /*case 'hotelbooking':
              ?> 
              <div class="hl-category-box hl-purple-bg">
                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/admin/images/hotel.png'); ?>" alt="<?php echo esc_attr__('Hotel icon','astro'); ?>">
                <h3><?php echo esc_html__('Hotel booking','astro'); ?></h3>
                <a class="hl-btn hl_disconnectbookings" data-startbookings="<?php echo esc_attr__('hotelbooking','astro'); ?>"><?php echo esc_html__('Disconnect','astro'); ?></a>
              </div>  
              <?php
              break;
              case 'cafebooking':
              ?>
              <div class="hl-category-box hl-blue-bg">
                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/admin/images/coffee.png'); ?>" alt="<?php echo esc_attr__('event icon','astro'); ?>">
                <h3><?php echo esc_html__('Event booking','astro'); ?></h3>
                <a class="hl-btn hl_disconnectbookings" data-startbookings="<?php echo esc_attr__('cafebooking','astro'); ?>"><?php echo esc_html__('Disconnect','astro'); ?></a>
              </div> 
              <?php
              break;
              */
              case 'appointmentbooking':
              ?>
              <div class="hl-category-box hl-orange-bg">
                 <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/admin/images/booking.png'); ?>" alt="<?php echo esc_attr__('Appointment icon','astro'); ?>">
                 <h3><?php echo esc_html__('Appointment booking','astro'); ?></h3>
                 <a class="hl-btn hl_disconnectbookings" data-startbookings="<?php echo esc_attr__('appointmentbooking','astro'); ?>"><?php echo esc_html__('Disconnect','astro'); ?></a> 
              </div>  
              <?php
              break;
            endswitch;
            ?>
        </div>
        <?php
         else:
        ?>
          <!--<div class="col-lg-4 col-md-6">
            <div class="hl-category-box hl-purple-bg">
            <img src="<?php // echo esc_url(plugins_url(). '/astro-appointment/admin/images/hotel.png'); ?>" alt="<?php // echo esc_attr__('Hotel icon','astro'); ?>">
            <h3><?php // echo esc_html__('Hotel booking','astro'); ?></h3>
            <a class="hl-btn hl_startbookings" data-startbookings="<?php    // echo esc_attr__('hotelbooking','astro'); ?>"><?php // echo esc_html__('Start','astro'); ?></a>
            </div>
          </div>-->
          <!--<div class="col-lg-6 col-md-6">
              <div class="hl-category-box hl-blue-bg">
              <img src="<?php // echo esc_url(plugins_url(). '/astro-appointment/admin/images/coffee.png'); ?>" alt="<?php // echo esc_attr__('event icon','astro'); ?>">
              <h3><?php  // echo esc_html__('Event booking','astro'); ?></h3>
              <a class="hl-btn hl_startbookings" data-startbookings="<?php // echo  esc_attr__('cafebooking','astro'); ?>"><?php // echo esc_html__('Start','astro'); ?></a>
              </div> 
          </div>-->
          <div class="col-lg-12 col-md-6">
              <div class="hl-category-box hl-orange-bg">
                <img src="<?php echo esc_url(plugins_url(). '/astro-appointment/admin/images/booking.png'); ?>" alt="<?php echo esc_attr__('Appointment icon','astro'); ?>">
                <h3><?php echo esc_html__('Appointment booking','astro'); ?></h3>
                <a class="hl-btn hl_startbookings" data-startbookings="<?php echo esc_attr__('appointmentbooking','astro'); ?>"><?php echo esc_html__('Start','astro'); ?></a> 
              </div>  
          </div> 
          <?php
          endif;
          ?>
          </div>
       </div>
      <!-- Loader Section Start  -->
      <div class="hl-preloader">
        <div class="hl-preloader-box">
        <svg xmlns="http://www.w3.org/2000/svg" width="200px" height="200px" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="0" fill="none" stroke="#ff8f91" stroke-width="2">
              <animate attributeName="r" repeatCount="indefinite" dur="0.78125s" values="0;35" keyTimes="0;1" keySplines="0 0.2 0.8 1" calcMode="spline" begin="0s"></animate>
              <animate attributeName="opacity" repeatCount="indefinite" dur="0.78125s" values="1;0" keyTimes="0;1" keySplines="0.2 0 0.8 1" calcMode="spline" begin="0s"></animate>
            </circle><circle cx="50" cy="50" r="0" fill="none" stroke="#ff8f91" stroke-width="2">
              <animate attributeName="r" repeatCount="indefinite" dur="0.78125s" values="0;35" keyTimes="0;1" keySplines="0 0.2 0.8 1" calcMode="spline" begin="-0.390625s"></animate>
              <animate attributeName="opacity" repeatCount="indefinite" dur="0.78125s" values="1;0" keyTimes="0;1" keySplines="0.2 0 0.8 1" calcMode="spline" begin="-0.390625s"></animate>
            </circle>
        </svg>
        </div>
      </div>
      <!-- Loader Section End -->
    </div> 
</div>