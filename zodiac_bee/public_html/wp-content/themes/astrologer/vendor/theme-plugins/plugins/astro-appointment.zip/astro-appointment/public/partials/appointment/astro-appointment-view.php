<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="hl-appointment-booking">
               <div id="appointment_date"></div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="hl-appointment-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      <div class="modal-body">
        <div class="hl-event-booking-form">
            <div class="hl-form-close">
                <span></span>
            </div>
            <form id="Astro_appointment_booking" name="Astro_appointment_booking" method="post" action="<?php echo esc_attr($_SERVER['PHP_SELF']);?>">
                <?php 
                 $booking_form_heading = get_option('appointment_booking_form_heading');
                 if(!empty($booking_form_heading)):
                    echo '<h4>'.esc_html__('Booking Form','astro').'</h4>';
                 endif;
                ?>
                <ul>
                    <li>
                    <label><?php echo esc_html__('Name','astro'); ?></label>
                    <input type="text" name="cust_name" id="cust_name">
                    </li>
                    <li>
                    <label><?php echo esc_html__('Email','astro'); ?></label>
                    <input type="text" name="cust_email" id="cust_email">
                    </li>
                    <li>
                    <label><?php echo esc_html__('Phone','astro'); ?></label>
                    <input type="number" name="cust_number" id="cust_number">
                    </li>
                    <li>
                     <label><?php echo esc_html__('Booking Date','astro'); ?></label>
                     <input type="text" name="appointment_booking_date" id="appointment_booking_date" value="" readonly>  
                    </li>
                    <li>
                    <label><?php echo esc_html__("Time","astro"); ?></label>
                      <div id="Astro_appointment_schedule"></div>
                    </li>
                     <li>
                     <label><?php echo esc_html__('Message','astro'); ?></label>
                    <textarea name="cust_message" id="cust_message" name="cust_message"></textarea>
                    </li>
                    <li>
                     <button class="hl-btn" id="appointment_booke" name="appointment_books"><?php echo esc_html__('Book Appointment','astro'); ?></button>
                    </li> 
                </ul>
            </form>
        </div>
      </div>
    </div>
  </div>
</div> 
<div id="appointment_payment_option" class="modal">
   <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        <div class="modal-header">
        <?php 
        $booking_review_heading = get_option('appointment_booking_review_heading');
        if(!empty($booking_review_heading)):
           echo '<h4>'.esc_html($booking_review_heading).'</h4>';
        endif;
        ?>
        </div>
       <div class="modal-body">
        <div class="hl-payment-astro" id="hl_appointment_review_date"></div> 
        <!-- Stripe Payment Option -->
        <div id="hl_appointment_stripe_option"></div>
        </div>  
      </div>
    </div>
</div>
<!-- Loader Section Start  -->
<div class="hl-preloader">
    <div class="hl-preloader-box">
        <svg xmlns="http://www.w3.org/2000/svg" width="200px" height="200px" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="0" fill="none" stroke="#ff8f91" stroke-width="2">
            <animate attributeName="r" repeatCount="indefinite" dur="0.78125s" values="0;35" keyTimes="0;1" keySplines="0 0.2 0.8 1" calcMode="spline" begin="0s"></animate>
            <animate attributeName="opacity" repeatCount="indefinite" dur="0.78125s" values="1;0" keyTimes="0;1" keySplines="0.2 0 0.8 1" calcMode="spline" begin="0s"></animate>
            </circle><circle cx="50" cy="50" r="0" fill="none" stroke="#ff8f91" stroke-width="2">
            <animate attributeName="r" repeatCount="indefinite" dur="0.78125s" values="0;35" keyTimes="0;1" keySplines="0 0.2 0.8 1" calcMode="spline" begin="-0.390625s"></animate>
            <animate attributeName="opacity" repeatCount="indefinite" dur="0.78125s" values="1;0" keyTimes="0;1" keySplines="0.2 0 0.8 1" calcMode="spline" begin="-0.390625s"></animate>
            </circle>
        </svg>
    </div>
</div>
<!-- Loader Section End -->