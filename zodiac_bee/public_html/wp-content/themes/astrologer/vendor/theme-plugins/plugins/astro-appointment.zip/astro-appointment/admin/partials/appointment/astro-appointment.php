<div class="hl-main-wraper">
   <div class="container-fluid">
        <div class="hl-card-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="hl-hotal-tabs">
                        <ul>  
                        <li>
                         <a href="<?php echo esc_url(admin_url('admin.php?page=appointment_schedule')); ?>"><img src="<?php echo esc_url(plugins_url(). '/astro-appointment/admin/images/bed.png'); ?>" alt="<?php esc_attr_e('Schedule Icon ','astro'); ?>"><?php echo esc_html__('Schedule','astro'); ?></a> 
                        </li> 
                        <li> 
                          <a href="<?php echo esc_url(admin_url('admin.php?page=appointment_booking')); ?>"><img src="<?php echo esc_url(plugins_url(). '/astro-appointment/admin/images/calendar.png'); ?>" alt="<?php esc_attr_e('Bookings icon','astro'); ?>"><?php echo esc_html__('Bookings','astro'); ?></a>
                        </li>
                        <li>
                         <a href="<?php echo esc_url(admin_url('admin.php?page=appointment_paymentsetting')); ?>"><img src="<?php echo esc_url(plugins_url(). '/astro-appointment/admin/images/credit-card.png'); ?>" alt="<?php esc_attr_e('Payment icon','astro'); ?>"><?php echo esc_html__('Payment Settings','astro'); ?></a>
                        </li>
                        <li>
                         <a href="<?php echo esc_url(admin_url('admin.php?page=appointment_formsetting')); ?>"><img src="<?php echo esc_url(plugins_url(). '/astro-appointment/admin/images/form.png'); ?>" alt="<?php esc_attr_e('Form icon','astro'); ?>"><?php echo esc_html__('Form Settings','astro'); ?></a> 
                        </li> 
                        </ul> 
                    </div>
                </div>
            </div>
            <?php
            $user_info = get_userdata(get_current_user_id()); 
            ?>
            <h1 class="hl-heading-title"><?php echo esc_html__('Welcome:','astro'); ?> <?php echo esc_html($user_info->user_nicename);?> </h1>
            <div class="hl-data-analytics">
                <div class="row">
                   <div class="col-lg-3 col-md-6 offset-3">
                        <div class="hl-category-box hl-purple-bg">
                            <?php 
                            global $wpdb;
                            $today_date = date("Y-m-d");
                            $table_name = $wpdb->prefix.'cafe_table_booked';
                            $count_posts = $wpdb->get_results("SELECT count(bc_id) AS todaybooking FROM $table_name WHERE bc_booking_date='$today_date'");  
                            if(!empty($count_posts[0]->todaybooking)):
                                echo '<h2>'.esc_html($count_posts[0]->todaybooking).'</h2>';
                            else:
                                echo '<h2>'.esc_html__('0','astro').'</h2>';
                            endif;
                            ?>
                            <h3><?php echo esc_html__('Today Total Booking','astro'); ?></h3> 
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="hl-category-box hl-blue-bg">
                        <?php 
                        $room_ids = array(); 
                        $book_results = $wpdb->get_results("SELECT SUM(bc_payment_amount) AS todayearning FROM $table_name WHERE bc_booking_date='$today_date'");
                        $display_currency = get_option('cafe_display_currency');
                        if(!empty($display_currency)):  
                           $currency_val = get_option('cafe_display_currency');
                        else:
                           $currency_val = get_option('stripe_cafe_currency_val');
                        endif; 
                        if(!empty($book_results[0]->todayearning)):
                            echo '<h2><span>'.esc_html($currency_val).'</span>'.esc_html($book_results[0]->todayearning).'</h2>';
                        else:
                            echo '<h2>'.esc_html__('0','astro').'</h2>';
                        endif;
                        ?>
                        <h3> 
                        <?php echo esc_html__('Today Earning','astro'); ?>
                        </h3> 
                        </div>
                    </div>
                </div>
            </div>
         </div>
    </div>
</div>