<?php 
 /**
* Shortode
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
} 
// Wp backey Shortcode Map
add_action( 'vc_before_init', 'Astro_room_view' );
function Astro_room_view(){
    vc_map( array(
		"name" => __( "Room View", "astro" ),
		"base" => "Astro_room",
		"category" => __("Astro","astro"), 
		"params" => array( 
		        
		),
	));
}