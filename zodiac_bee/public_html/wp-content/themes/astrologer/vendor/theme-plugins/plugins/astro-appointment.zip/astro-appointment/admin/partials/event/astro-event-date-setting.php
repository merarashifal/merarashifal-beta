<?php
/***
 * Astro Custom Post Type For Create Schedule 
 */
$r_labels = array(
    'name' => esc_html__( 'Astro Event Dete Setting', 'astro' ),
    'singular_name' => esc_html__( 'Astro Event Dete Setting', 'astro' ),
    'menu_name'  => esc_html__( 'Astro Event Dete Setting', 'admin menu', 'astro' ),
    'name_admin_bar' => _x( 'Astro Event Dete Setting', 'add new on admin bar', 'astro' ),
    'add_new' => _x( 'Add New', 'Event Dete Setting', 'astro' ),
    'add_new_item' => esc_html__( 'Add New Event Dete Setting', 'astro' ),
    'new_item'  => esc_html__( 'New Event Dete Setting', 'astro' ),
    'edit_item' => esc_html__( 'Edit Event Dete Setting', 'astro' ),
    'view_item' => esc_html__( 'View Event Dete Setting', 'astro' ),
    'all_items' => esc_html__( 'All Event Dete Setting', 'astro' ),
    'search_items' => esc_html__( 'Search Event Dete Setting', 'astro' ),
    'parent_item_colon'  => esc_html__( 'Parent Event Dete Setting:', 'astro' ),
    'not_found' => esc_html__( 'No Event Dete Setting found.', 'astro' ),
    'not_found_in_trash' => esc_html__( 'No Event Dete Setting found in Trash.', 'astro' )
   );
$hr_args = array(
    'labels'             => $r_labels,
    'description'        => esc_html__( 'Description.', 'astro' ),
    'public'             => true,
    'publicly_queryable' => true,
    'show_ui'            => true,
    'show_in_menu'       => false,
    'query_var'          => true,
    'rewrite'            => array( 'slug' => 'cafe_date' ),
    'capability_type'    => 'post',
    'has_archive'        => true,
    'hierarchical'       => false,
    'menu_position'      => null,
    'menu_icon'          => 'dashicons-video-alt3',
    'supports'           => array( 'title')
   );
register_post_type('cafe_date', $hr_args );  